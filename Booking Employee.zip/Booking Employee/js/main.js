var searchButton=document.getElementById('s-button'),
    searchDiv=document.getElementById('search'),
    Trips=document.getElementById('trips'),
    trip = document.getElementById('tripspan'),

    from = document.getElementById('from'),
    fSpan=document.getElementById('fspan'),

    to = document.getElementById('to'),
    tSpan=document.getElementById('tspan'),

    timeSpan=document.getElementById('timespan'),

    dnSpan=document.getElementById('dnspan'),

    daySpan=document.getElementById('dayspan'),
 
    yearSpan=document.getElementById('yearspan'),

    monthSpan=document.getElementById('monthspan'),

    bookButton=document.getElementById('b-button'),
    cancelButton=document.getElementById('c-button'),
    tripid,
    arr;

/*async function BookingEmployeeSearch() {
    //data to be sent
    let dataToSend = {
        location: from.options[from.selectedIndex].value, //source
        destination: to.options[to.selectedIndex].value, //destination
    };
    //--------------------------------
    let response = await fetch("http://127.0.0.1:8080/BookingEmployeeSearch", {
        method: "POST",
        body: JSON.stringify(dataToSend),
        headers: {
        "Content-Type": "application/json",
        },
    });
    let resivedData = await response.json();
    //display the data
    arr=resivedData;
    //-------------------------------
    }*/

searchButton.onclick = function(){
        "use strict";
        
        searchDiv.classList.remove('hide');
        //await BookingEmployeeSearch();
        for(var i=0;i<5;i++)
        {
           // arr[i];
            var t=document.createElement('div');
            t.classList.add('t-info');
            var tid=document.createElement('p');
            var tidspan=document.createElement('span');
            tid.innerHTML='id:';
            tidspan.innerHTML='111'+i;
            tid.classList.add('t-infop');
            t.appendChild(tid);
            t.appendChild(tidspan);
            tidspan.classList.add('tripsspan');

            var tdes=document.createElement('p');
            tdes.innerHTML='Destination: ' +to.options[to.selectedIndex].value ;
            tdes.classList.add('t-infop');
            t.appendChild(tdes);

            var tdate=document.createElement('p');
            tdate.innerHTML='Date: 20/10/2021';
            tdate.classList.add('t-infop');
            t.appendChild(tdate);

            var tdur=document.createElement('p');
            tdur.innerHTML='Duration: 4h';
            tdur.classList.add('t-infop');
            t.appendChild(tdur);

            var tcost=document.createElement('p');
            tcost.innerHTML='Cost: 20EGP';
            tcost.classList.add('t-infop');
            t.appendChild(tcost);
            
            Trips.appendChild(t);   

        }
};

/*async function BookingEmployeeBook() {
    //data to be sent
    let dataToSend = {
      id: tripid, //bus id
    };
    //--------------------------------
    let response = await fetch("http://127.0.0.1:8080/BookingEmployeeBook", {
      method: "POST",
      body: JSON.stringify(dataToSend),
      headers: {
        "Content-Type": "application/json",
      },
    });
    let resivedData = await response.json();
    //display the data
    console.log(resivedData);
    //-------------------------------
  }
bookButton.onclick = function(){
    "use strict";
    await BookingEmployeeBook();
    searchDiv.classList.add('hide');
};


async function BookingEmployeeCancel() {
    //data to be sent
    let dataToSend = {
      id: tripid, //bus id
    };
    //--------------------------------
    let response = await fetch("http://127.0.0.1:8080/BookingEmployeeCancel", {
      method: "POST",
      body: JSON.stringify(dataToSend),
      headers: {
        "Content-Type": "application/json",
      },
    });
    let resivedData = await response.json();
    //display the data
    console.log(resivedData);
    //-------------------------------
  }
cancelButton.onclick = function(){
    "use strict";
    await BookingEmployeeCancel();
    searchDiv.classList.add('hide');
};

//trip.innerHTML="#123456";

/*from.onchange=function(){
    "use strict";
    fSpan.innerHTML=from.options[from.selectedIndex].value;
};

to.onchange=function(){
    "use strict";
    tSpan.innerHTML=to.options[to.selectedIndex].value;
};

time.onchange=function(){
    "use strict";
    timeSpan.innerHTML=time.options[time.selectedIndex].value;
};
dn.onchange=function(){
    "use strict";
    dnSpan.innerHTML=dn.options[dn.selectedIndex].value;
};

day.onchange=function(){
    "use strict";
    daySpan.innerHTML=day.options[day.selectedIndex].value;
};
month.onchange=function(){
    "use strict";
    monthSpan.innerHTML=month.options[month.selectedIndex].value;
};
year.onchange=function(){
    "use strict";
    yearSpan.innerHTML=year.options[year.selectedIndex].value;
};*/

document.onclick=function(e){
    "use strict";
    if(e.target.classList.contains('tripsspan'))
    {
       // tripid=${tidspan};

        console.log(tripid);
    }
};